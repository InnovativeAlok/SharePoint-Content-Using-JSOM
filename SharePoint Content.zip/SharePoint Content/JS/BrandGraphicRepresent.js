var spItems,SKUItems,countSKUID,month,brandID,flavourID,delta,
    pvmiSKUList = 'lstPVMISKUList';
    var lstRudrapur = [];
    var lstChennai = [];
	var lstManeser = [];
	var uniqueRudrapur = [];
	var uniqueChennai = [];
	var uniqueManeser = [];
	var dataPointsRudrapur = [];
	var dataPointsChennai = [];
	var dataPointsManeser = [];


// This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
$(document).ready(function () {
    debugger;
    // Make sure the SharePoint script file 'sp.js' is loaded before your code runs.
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', sharePointReady);
    // Create an instance of the current clientContext.
    function sharePointReady() {
        getBrandDetailsLocationWise();
    }
});

function getBrandDetailsLocationWise() {
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle(pvmiSKUList);
    var camlQuery = new SP.CamlQuery();

    camlQuery.set_viewXml("<View><ViewFields><FieldRef Name='ID'/><FieldRef Name='LocationID_x003a_Location_x0020_'/>" +
    					  "<FieldRef Name='BrandID_x003a_Brand_x0020_Name'/></ViewFields></View>");


    spItems = list.getItems(camlQuery);

    context.load(spItems);

	context.executeQueryAsync(
	            function () {
	                onSuccess();
	            }, onFail);
}

function onSuccess() {
    var listEnumerator = spItems.getEnumerator();
    var item;

    while (listEnumerator.moveNext()) {
        item = listEnumerator.get_current();
        if(item.get_item("LocationID_x003a_Location_x0020_").get_lookupValue() == 'Rudrapur'){
			lstRudrapur.push(item.get_item('BrandID_x003a_Brand_x0020_Name').get_lookupValue());
        }
        if(item.get_item("LocationID_x003a_Location_x0020_").get_lookupValue() == 'Manesar'){
			lstManeser.push(item.get_item('BrandID_x003a_Brand_x0020_Name').get_lookupValue());        
        }
        if(item.get_item("LocationID_x003a_Location_x0020_").get_lookupValue() == 'Chennai'){
        	lstChennai.push(item.get_item('BrandID_x003a_Brand_x0020_Name').get_lookupValue());
        }
    }
    uniqueArray(lstRudrapur,uniqueRudrapur);
    uniqueArray(lstChennai,uniqueChennai);
    uniqueArray(lstManeser,uniqueManeser);
    
    bindRudrapurChart(uniqueRudrapur);
    bindChennaiChart(uniqueChennai);
    bindManeserChart(uniqueManeser);
}

// This function is executed if the above call fails
function onFail(sender, args) {
    alert('Failed to get items. Error:' + args.get_message());
}

function uniqueArray(names,uniqueNames){
	$.each(names, function(i, el){
	    if($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
	});
}

function bindRudrapurChart(uniqueRudrapur){
	for(var i = 0; i < uniqueRudrapur.length; i++){
		dataPointsRudrapur.push({y: i, name: uniqueRudrapur[i]});		
	}
	var chart = new CanvasJS.Chart("chartRudrapur",
	{
		zoomEnabled: true,
		title:{
			text: "Brands in Rudrapur"
		},
		exportFileName: "Pie Chart",
		exportEnabled: true,
                animationEnabled: true,
		legend:{
			verticalAlign: "bottom",
			horizontalAlign: "center"
		},
		data: [
		{       
			type: "pie",
			showInLegend: true,
			toolTipContent: "{name}: <strong>{y}%</strong>",
			indexLabel: "{name} {y}%",
			dataPoints: dataPointsRudrapur
	}
	]
	});
	chart.render();
}

function bindChennaiChart(uniqueChennai){
	for(var i = 0; i < uniqueChennai.length; i++){
		dataPointsChennai.push({y: i, name: uniqueChennai[i]});		
	}
	var chart = new CanvasJS.Chart("chartChennai",
	{
		title:{
			text: "Brands in Chennai"
		},
		exportFileName: "Pie Chart",
		exportEnabled: true,
                animationEnabled: true,
		legend:{
			verticalAlign: "bottom",
			horizontalAlign: "center"
		},
		data: [
		{       
			type: "pie",
			showInLegend: true,
			toolTipContent: "{name}: <strong>{y}%</strong>",
			indexLabel: "{name} {y}%",
			dataPoints: dataPointsChennai
	}
	]
	});
	chart.render();
}

function bindManeserChart(uniqueManeser){
	for(var i = 0; i < uniqueManeser.length; i++){
		dataPointsManeser.push({y: i, name: uniqueManeser[i]});		
	}
	var chart = new CanvasJS.Chart("chartManeser",
	{
		title:{
			text: "Brands in Manesar"
		},
		exportFileName: "Pie Chart",
		exportEnabled: true,
                animationEnabled: true,
		legend:{
			verticalAlign: "bottom",
			horizontalAlign: "center"
		},
		data: [
		{       
			type: "pie",
			showInLegend: true,
			toolTipContent: "{name}: <strong>{y}%</strong>",
			indexLabel: "{name} {y}%",
			dataPoints: dataPointsManeser
	}
	]
	});
	chart.render();
}



