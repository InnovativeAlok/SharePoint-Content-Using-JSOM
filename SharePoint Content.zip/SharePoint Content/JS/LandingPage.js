var spItems,position,
    nextPagingInfo,
    previousPagingInfo,
    spBnFItems,
    sortColumn = 'BrandID_x003a_Brand_x0020_Name',
    pvmiSKUList = 'lstPVMISKUList',
    pageIndex = 1, // default page index value 
    pageSize =null,  // default page size value
    searchMode = 'all',
    count = 0,
    libList = "",
    Actualdelta = "";
    var itemsUrl = [];
    var listDelta = [];
    var BnFitems = [];
    var lstBnFitem = [];
	var arr = [];
	var duplicateArray = [];
	var uniqueArray = [];
	var actualArr = [];


function getval(sel)
{
    if(sel != undefined){
       pageSize = sel.value;
       getData();	
    }		
    else{
       pageSize = 200;    
    }
	
}



// This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
$(document).ready(function () {
    debugger;	
    getval();
	
    // Make sure the SharePoint script file 'sp.js' is loaded before your code runs.
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', sharePointReady);
    // Create an instance of the current clientContext.
    function sharePointReady() {
        getAttachmentURL();
    }

    $("#btnNext").click(function () {
        pageIndex = pageIndex + 1;
        if (nextPagingInfo) {
            position = new SP.ListItemCollectionPosition();
            position.set_pagingInfo(nextPagingInfo);
		    getData();
			//DivWidth();            
        }
        else {
            position = null;
		    getData();
			//DivWidth();            
        }


    });

    $("#btnBack").click(function () {
        pageIndex = pageIndex - 1;
        position = new SP.ListItemCollectionPosition();
        position.set_pagingInfo(previousPagingInfo);
        getData();
    });

});

function DivWidth()
{
	debugger;
 	var scWidth = screen.width;
        var newscWidth = scWidth * (4.4 / 100);
        scWidth = scWidth - newscWidth;
        var divGrid = document.getElementById('divGrid');
        divGrid.style.width = scWidth + 'px';
};

function getData() {
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle(pvmiSKUList);

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_listItemCollectionPosition(position);

    camlQuery.set_viewXml("<View><Query><Where><Eq><FieldRef Name='Status' /><Value Type='Text'>Approved</Value></Eq>"+
    					   "</Where><OrderBy><FieldRef Name='BrandID_x003a_Brand_x0020_Name' Ascending='True'/><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' Ascending='True'/></OrderBy></Query>"+
    					   "<ViewFields><FieldRef Name='ID'/><FieldRef Name='BrandID'/><FieldRef Name='BrandID_x003a_Brand_x0020_Name'/>"+
    					   "<FieldRef Name='FlavourID'/><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na'/>" +
    					   "<FieldRef Name='LocationID_x003a_Location_x0020_'/><FieldRef Name='TargetWeightRetailUnit'/>"+
    					   "<FieldRef Name='QAActualWeightRetailUnit'/><FieldRef Name='LastModified'/></ViewFields>"+
    					   "<RowLimit>"+pageSize+"</RowLimit></View>");


    spItems = list.getItems(camlQuery);

	
    context.load(spItems);

    context.executeQueryAsync(
                function () {
                    onSuccess();
                }, onFail);
}

// Create a CAML view that retrieves items with assigne RowLimit value to the query  

// This function is executed if the above OM call is successful 
// This function render the returns items to html table
	var sn = 1; 
function onSuccess() {
    var listEnumerator = spItems.getEnumerator();
    var items = [];
    var item;
    while (listEnumerator.moveNext()) {
        item = listEnumerator.get_current();
        var item_id = item.get_id();
        
    	productionDate = item.get_item('LastModified');

    	if(productionDate != null){
	    	getHour(productionDate);
    	}
    	
        var QAActualWeightRetailUnit = item.get_item('QAActualWeightRetailUnit');
        var TargetWeightRetailUnit = item.get_item('TargetWeightRetailUnit');        
        
        calculateDelta(QAActualWeightRetailUnit,TargetWeightRetailUnit);
        
        //itemsUrl
        for(var i = 0; i<itemsUrl.length;i++){
			var test_str = itemsUrl[i];
			var mainItemURL = "";
			var start_pos = test_str.indexOf('LibSKU/') + 7;
			var end_pos = test_str.indexOf('/',start_pos);
			var text_to_get = test_str.substring(start_pos,end_pos);
			if(item_id == text_to_get){
				mainItemURL = "<a href='" + itemsUrl[i] +"' target='_blank'>ATTACHMENT</a>";
				break;
			}
			else{
				mainItemURL = "<a href='#' target='_blank'>NO ATTACHMENT</a>";
			}
        }
        
		if(Actualdelta == "NO PRODUCTION" && modifiedDate == "NO PRODUCTION"){
			Actualdelta = "<span style='color:red;'>"+ Actualdelta +"</span>";
			modifiedDate = "<span style='color:red;'>"+ modifiedDate +"</span>";			
		}
		else{
			Actualdelta = "<span style='color:green;'>"+ Actualdelta +"</span>";
			modifiedDate = "<span style='color:green;'>"+ modifiedDate +"</span>";			
		}
		function lstBnFItems(){
			for(var i = 0; i < BnFitems.length; i++){
				lstBnFitem.push(BnFitems[i].split("_"));										
			}
		}
		
		
        items.push("<td style='vertical-align:middle;'>" +
        "<a href='"+_spPageContextInfo.webAbsoluteUrl+"/Pages/BrandDetail.aspx?BRANDID="+item.get_item('BrandID').get_lookupValue()+"&FLAVOURID="+item.get_item('FlavourID').get_lookupValue()+"'>"+item.get_item('BrandID_x003a_Brand_x0020_Name').get_lookupValue()+"</a>" + 
        "</td><td  style='vertical-align:middle;'><a href='"+_spPageContextInfo.webAbsoluteUrl+"/Pages/BrandDetail.aspx?BRANDID="+item.get_item('BrandID').get_lookupValue()+"&FLAVOURID="+item.get_item('FlavourID').get_lookupValue()+"'>"+item.get_item('FlavourID_x003a_Flavour_x0020_Na').get_lookupValue()+"</a>" +
        "</td><td style='vertical-align:middle;'>" + item.get_item('LocationID_x003a_Location_x0020_').get_lookupValue() +
        "</td><td>" + Actualdelta +
		"</td><td>" + mainItemURL +        
        "</td><td>" + modifiedDate);
        sn++;
        }

    var content = "<div id='divGrid' style='overflow-x: scroll!Important;'><table class='Gridtable Gridtable-hover Gridtable-bordered'  id='pagingData'>" +
    "<thead><tr>"+
    //"<th>S. NO.</th>" +	
    "<th>BRAND NAME</th>" +
    "<th>FLAVOUR NAME</th>" +
    "<th>PLANT</th>" +
    "<th>GIVE AWAY DELTA(%)</th>" +
	"<th>PRODUCT SPECIFICATION</th>" +    
    "<th>LAST UPDATED ON</th>" +
    "</tr></thead><tbody><tr>" + items.join("</tr><tr>") + "</tr></tbody></table></div>";

	$('#content').html(content);

	groupTable($('#pagingData tr:has(td)'),0,3);
	$('#pagingData .deleted').remove();

    managePagerControl();
}

function managePagerControl() {

    if (spItems.get_listItemCollectionPosition()) {
        nextPagingInfo = spItems.get_listItemCollectionPosition().get_pagingInfo();
    } else {
        nextPagingInfo = null;
    }

    //The following code line shall add page information between the next and back buttons 
    $("#pageInfo").html((((pageIndex - 1) * pageSize) + 1) + " - " + ((pageIndex * pageSize) - (pageSize - spItems.get_count())));

    previousPagingInfo = "PagedPrev=TRUE&Paged=TRUE&p_ID=" + spItems.itemAt(0).get_item('ID') + "&p_" + sortColumn + "=" + encodeURIComponent(spItems.itemAt(0).get_item(sortColumn).get_lookupValue());

    if (pageIndex <= 1) {
        $("#btnBack").attr('disabled', 'disabled');
    }
    else {
        $("#btnBack").removeAttr('disabled');
    }

    if (nextPagingInfo) {
        $("#btnNext").removeAttr('disabled');
    }
    else {
        $("#btnNext").attr('disabled', 'disabled');
    }
}

// This function is executed if the above call fails
function onFail(sender, args) {
    alert('Failed to get items. Error:' + args.get_message());
}

//Code for find attachment URL
function getAttachmentURL(){
    var context = SP.ClientContext.get_current();
    webURL = context.get_web();
    var list = context.get_web().get_lists().getByTitle("LibSKU");

    //count = list.get_count();

    var camlQuery = new SP.CamlQuery.createAllItemsQuery();
    camlQuery.set_viewXml("<View Scope='RecursiveAll'><Query><Where><Neq><FieldRef Name='ContentType' />"+
    						"<Value Type='Text'>Folder</Value></Neq>"+
    						"</Where></Query></View>");
    this.collListItem = list.getItems(camlQuery);
    context.load(this.collListItem,"Include(FileLeafRef, ServerUrl, SKUID, ContentType)");
    context.executeQueryAsync(
                function () {
                    onGetAttachmentSuccess();
                }, onGetAttachmentFail);
}


function onGetAttachmentSuccess(){
    var listEnumerator = this.collListItem.getEnumerator();
    var currentItem;
    while(listEnumerator.moveNext()){
    	var libList= "";
    	currentItem = listEnumerator.get_current();
    	
    	var currentItemURL = _spPageContextInfo.webAbsoluteUrl + currentItem.get_item('ServerUrl');
    	var ItemUrl = currentItemURL.replace('/pvmisku/pvmisku/','/pvmisku/');  
		itemsUrl.push(ItemUrl);
    }
            getData();	
}

function onGetAttachmentFail(sender,args){
	alert('Failed to get items. Error:' + args.get_message());
}


	function getHour(prdHour){
		var h1 = prdHour.toString().split(" ");
		var h2 = h1[4];
		var h3 = h2.split(":");
		var h4 = h3;
		var strHour = h4[0];
		hour = Number(strHour);
	}


function calculateDelta(QAActualWeightRetailUnit,TargetWeightRetailUnit){
		if(QAActualWeightRetailUnit == 0){
			Actualdelta = "NO PRODUCTION";
			modifiedDate = "NO PRODUCTION";			
		}
        var preDelta = ((QAActualWeightRetailUnit/TargetWeightRetailUnit)*100);
       
		if(preDelta > 0){
			delta = parseFloat(preDelta - 100).toFixed(2);
			Actualdelta = (delta).toString();
			modifiedDate = productionDate.format('dd MMM yyyy, hh:ss');
			if(hour < 12 || hour == 12 )
				modifiedDate = modifiedDate + " AM";
			else
				modifiedDate = modifiedDate + " PM";	
		}

		else{
			Actualdelta = "NO PRODUCTION";
			modifiedDate = "NO PRODUCTION";
		}
}

		function groupTable($rows, startIndex, total){
		if (total === 0){
		return;
		}
		var i , currentIndex = startIndex, count=1, lst=[];
		var tds = $rows.find('td:eq('+ currentIndex +')');
		var ctrl = $(tds[0]);
		lst.push($rows[0]);
		for (i=1;i<=tds.length;i++){
		if (ctrl.text() ==  $(tds[i]).text()){
		count++;
		$(tds[i]).addClass('deleted');
		lst.push($rows[i]);
		}
		else{
		if (count>1){
		ctrl.attr('rowspan',count);
		groupTable($(lst),startIndex+1,total-1)
		}
		count=1;
		lst = [];
		ctrl=$(tds[i]);
		lst.push($rows[i]);
		}
		}
		}

function fnExcelReport()
{
	debugger;
    var tab_text="<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j=0;
    tab = document.getElementById('pagingData'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xlsx");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}