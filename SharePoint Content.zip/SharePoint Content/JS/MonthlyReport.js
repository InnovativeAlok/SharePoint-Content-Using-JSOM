var spReportItems,position,spItems,brandID,flavourID,selYear,delta,nextPagingInfo,previousPagingInfo,
    spQUAItems,selMonth,sortColumn = 'Title',pageIndex = 1,lstPVMSKUQA = 'lstPVMSKUQA',Actualdelta,
    selBrand,selPack,selPlant,selFlavour,selRetailUnit,pageSize = 10,lstPVMISKUList = 'lstPVMISKUList';
    var deltaArray = [];
    var duplicateArray = [];
    var uniqueArray = [];
    var lstMonth = ['JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER'];
    var d = new Date();
	var curYear = d.getFullYear();
	var curMonth = d.getMonth();
	var monthContent = [];     
    var QUAItems = [];
    var QUAItem = [];
	var uniqueItem = [];
	var testItem = [];
	var ytdCollection = [];
	var ytdItems = [];
	var ytdItem = [];
	var tempArr = [];
	    
// This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
$(document).ready(function () {
    debugger;
    // Make sure the SharePoint script file 'sp.js' is loaded before your code runs.
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', sharePointReady);
    $("#btnNext").click(function () {
	    pageIndex = pageIndex + 1;
	    if (nextPagingInfo) {
	        position = new SP.ListItemCollectionPosition();
	        position.set_pagingInfo(nextPagingInfo);
	        getReport();
	    }
	    else {
	        position = null;
	        getReport();
	    }
    });
    

    $("#btnBack").click(function () {
        pageIndex = pageIndex - 1;
        position = new SP.ListItemCollectionPosition();
        position.set_pagingInfo(previousPagingInfo);
        getReport();
    });

});

    function getPack(inputVal){
    	selPack = inputVal.value;
    }

function getRecord(){
	getQUAData();
}
//Selected Value
function getSelctedVal(selected){
	if(selected.name == "Year")
	selYear = selected.value;

	if(selected.name == "Month"){
	selMonth = selected.value;
	}

	if(selected.name == "Brand")
	selBrand = selected.value;

	if(selected.name == "Flavour")
	selFlavour = selected.value;

	if(selected.name == "Plant")
	selPlant = selected.value;

	if(selected.name == "RetailUnit")
	selRetailUnit = selected.value;

}

    
    // Create an instance of the current clientContext.
    function sharePointReady() {
        getYear();
        getBrand();
        getPlant();
        getFlavour();
        getRetailUnit();
	}

// Bind Brand
function getBrand(){
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle('lstBrands');
    var camlQuery = new SP.CamlQuery();

    spBrandItems = list.getItems(camlQuery);

    context.load(spBrandItems);

    context.executeQueryAsync(
                function () {
                    onBrandSuccess();
                }, onBrandFail);	
	
}	

function onBrandSuccess(){
    var listEnumerator = spBrandItems.getEnumerator();
    var items = [];
    var item;

    while (listEnumerator.moveNext()) {
        item = listEnumerator.get_current();
		items.push("<option>"+ item.get_item('Title') +"</option>");
    }
    var content = "Brand : <select name='Brand' onchange='getSelctedVal(this);'><option value='0'>SELECT</option>"+ items.join() +"</select>";
    $('#ddlBrand').html(content);	
}

function onBrandFail(sender,args){
    alert('Failed to get items. Error:' + args.get_message());
}


// Bind Plant	
function getPlant(){
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle('lstLocation');
    var camlQuery = new SP.CamlQuery();

    spPlantItems = list.getItems(camlQuery);

    context.load(spPlantItems);

    context.executeQueryAsync(
                function () {
                    onPlantSuccess();
                }, onPlantFail);	
	
}	

function onPlantSuccess(){
    var listEnumerator = spPlantItems.getEnumerator();
    var items = [];
    var item;

    while (listEnumerator.moveNext()) {
        item = listEnumerator.get_current();
		items.push("<option>"+ item.get_item('Title') +"</option>");
    }
    var content = "Plant : <select name='Plant' onchange='getSelctedVal(this);'><option value='0'>SELECT</option>"+ items.join() +"</select>";
    $('#ddlPlant').html(content);	
}

function onPlantFail(sender,args){
    alert('Failed to get items. Error:' + args.get_message());
}

// Bind Flavour
function getFlavour(){
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle('lstFlavours');
    var camlQuery = new SP.CamlQuery();

    spFlavourItems = list.getItems(camlQuery);

    context.load(spFlavourItems);

    context.executeQueryAsync(
                function () {
                    onFlavourSuccess();
                }, onFlavourFail);	
	
}	

function onFlavourSuccess(){
    var listEnumerator = spFlavourItems.getEnumerator();
    var items = [];
    var item;

    while (listEnumerator.moveNext()) {
        item = listEnumerator.get_current();
		items.push("<option>"+ item.get_item('Title') +"</option>");
    }
    var content = "Flavour : <select name='Flavour' onchange='getSelctedVal(this);'><option value='0'>SELECT</option>"+ items.join() +"</select>";
    $('#ddlFlavour').html(content);	
}

function onFlavourFail(sender,args){
    alert('Failed to get items. Error:' + args.get_message());
}

// Bind RetailUnit
function getRetailUnit(){
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle('lstRetailUnit');
    var camlQuery = new SP.CamlQuery();

    spRetailUnitItems = list.getItems(camlQuery);

    context.load(spRetailUnitItems);

    context.executeQueryAsync(
                function () {
                    onRetailUnitSuccess();
                }, onRetailUnitFail);	
	
}	

function onRetailUnitSuccess(){
    var listEnumerator = spRetailUnitItems.getEnumerator();
    var items = [];
    var item;

    while (listEnumerator.moveNext()) {
        item = listEnumerator.get_current();
		items.push("<option>"+ item.get_item('Title') +"</option>");
    }
    var content = "Retail Unit : <select name='RetailUnit' onchange='getSelctedVal(this);'><option value='0'>SELECT</option>"+ items.join() +"</select>";
    $('#ddlRetailUnit').html(content);	
}

function onRetailUnitFail(sender,args){
    alert('Failed to get items. Error:' + args.get_message());
}


function getQUAData(){
	//Validate
	if(selYear == undefined || selYear == ""){
		alert("Please select Year");
		return false;
	}
	if(selMonth == undefined || selMonth == ""){
		alert("Please select Month");
		return false;
	}
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle(lstPVMSKUQA);
    var camlQuery = new SP.CamlQuery();
    
    var query = "";
    
    if(selMonth == "YTD"){
	    query += "<View><Query><Where><Eq><FieldRef Name='Title'/><Value Type='Text'>"+ selYear +"</Value></Eq></Where>";
	    query += "<OrderBy><FieldRef Name='SKUID' Ascending='True'/></OrderBy></Query></View>";
    }
    else{
	    query += "<View><Query><Where><And><Eq><FieldRef Name='Title'/><Value Type='Text'>"+ selYear +"</Value></Eq>";
	    query += "<Eq><FieldRef Name='Month'/><Value Type='Text'>"+ selMonth +"</Value></Eq></And></Where>";
	    query += "<OrderBy><FieldRef Name='SKUID' Ascending='True'/></OrderBy></Query></View>";
    }
    
    
    camlQuery.set_viewXml(query);


    spQUAItems = list.getItems(camlQuery);

    context.load(spQUAItems);

    context.executeQueryAsync(
                function () {
                    onQUASuccess();
                }, onQUAFail);	
}

function onQUASuccess(){
    var listEnumerator = spQUAItems.getEnumerator();
    var item;

    while (listEnumerator.moveNext()) {
        item = listEnumerator.get_current();

        QUAItems.push(item.get_item('SKUID').get_lookupValue()+"_"+item.get_item('QAActualWeightOfSinglePiece')+"_"+
        item.get_item('QAActualNoOfPiecesPerSaleUnit')+"_"+item.get_item('QAActualNoOfSalesUnitPerRetailUn')+"_"+
        item.get_item('QAActualWeightRetailUnit'));
    }
    splitArray(QUAItems,QUAItem,testItem);
    getReport();
}

function onQUAFail(sender,args){
    alert('Failed to get items. Error:' + args.get_message());
}

function calculateDelta(QAActualWeightRetailUnit,TargetWeightRetailUnit){
		if(QAActualWeightRetailUnit == 0){
			Actualdelta = "NO PRODUCTION";
		}
        var preDelta = ((QAActualWeightRetailUnit/TargetWeightRetailUnit)*100);
       
		if(preDelta > 0){
			delta = parseFloat(preDelta - 100).toFixed(2);
			Actualdelta = "<span style='color:green ;'>"+(delta).toString()+"</span>";
		}

		else{
			Actualdelta = "<span style='color:red;'>NO PRODUCTION</span>";
		}
}

function DivWidth()
{
	debugger;
 	var scWidth = screen.width;
        var newscWidth = scWidth * (4.4 / 100);
        scWidth = scWidth - newscWidth;
        var divGrid = document.getElementById('divGrid');
        divGrid.style.width = scWidth + 'px';
};

function getYear() {
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle(lstPVMSKUQA);
    var camlQuery = new SP.CamlQuery();

    camlQuery.set_viewXml("<View><OrderBy><FieldRef Name = 'ID' Ascending = 'False'/></OrderBy></View>");


    spItems = list.getItems(camlQuery);

    context.load(spItems);

    context.executeQueryAsync(
	    function () {
	        onSuccess();
	    }, onFail);
}

// Create a CAML view that retrieves items with assigne RowLimit value to the query  

// This function is executed if the above OM call is successful 
// This function render the returns items to html table 
function onSuccess() {
    var listEnumerator = spItems.getEnumerator();
    var items = [];
    var yearItems = [];
    var item;

    while (listEnumerator.moveNext()) {
        item = listEnumerator.get_current();
        items.push(item.get_item('Title'));
    }
    getUniqueYear(items);
    if(uniqueArray != null && uniqueArray.length > 0){
		for(var i = 0; i < uniqueArray.length; i++){
			yearItems.push("<option>"+ uniqueArray[i] +"</option>");
		}
		var content = "YEAR : <select name='Year' onchange='getSelctedVal(this);'><option value='0'>Select</option>"+ yearItems.join() +"</select>";
		$('#ddlYear').html(content);
    }
    else{
		var content = "YEAR : <select name='Year' onchange='getSelctedVal(this);'><option value='0'>Select</option>"+ curYear +"</select>";
		$('#ddlYear').html(content);    
    }
    getMonth();
}

// This function is executed if the above call fails
function onFail(sender, args) {
    alert('Failed to get items. Error:' + args.get_message());
}

function getUniqueYear(items){
	var sorted_arr = items.slice().sort();
	for(var i = 0; i < items.length; i++){
		if( sorted_arr[i+1] === sorted_arr[i] ){
			duplicateArray.push(sorted_arr[i]);
		}					
		else{
			uniqueArray.push(sorted_arr[i]);		
		}
	}
}

function getMonth(){
	if(selYear > 0){
		if(selYear == curYear){
			for(var i = 0; i < curMonth; i++){
				monthContent.push("<option value='"+(i+1)+"'>"+ lstMonth[i] +"</option>");
			}
		}
		else if(selYear < curYear){
			for(var i = 0; i < 12; i++){
				monthContent.push("<option value='"+(i+1)+"'>"+ lstMonth[i] +"</option>");
			}		
		}		
	}
	else{
		for(var i = 0; i < curMonth; i++){
				monthContent.push("<option value='"+(i+1)+"'>"+ lstMonth[i] +"</option>");
		}
	}
	var content = "Month : <select name='Month' onchange='getSelctedVal(this);'><option value='0'>Select</option>"+ monthContent.join() +"<option>YTD</option></select>";
	$('#ddlMonth').html(content);    									
}
	function splitArray(Items,Item,splitedItems){
	    for(var i = 0; i < Items.length; i++){
			Item.push(Items[i].split("_"));
			splitedItems.push(Item[i][0]);
		}
	}

function getReport(){
	$.each(testItem, function(i, el){
	    if($.inArray(el, uniqueItem) === -1) uniqueItem.push(el);
	});			
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle(lstPVMISKUList);
    var camlQuery = new SP.CamlQuery();

    if(selMonth != "YTD"){
	    camlQuery.set_listItemCollectionPosition(position);
    }

	var query = "";
	var rowQuery = "";
    	
	query += "<View><Query><Where>";
	if((selFlavour != undefined) || (selBrand != undefined) || (selPlant != undefined) || (selPack != undefined) || (selRetailUnit != undefined)){
		query += "<And>";
	}
	if(selMonth == "YTD"){
		query += "<In><FieldRef Name='ID'/><Values>";
		for(var i = 0; i < uniqueItem.length; i++){
			query += "<Value Type='Counter'>"+ uniqueItem[i] +"</Value>";
		}
		query += "</Values></In>";
	}	
	else{
		for(var i = QUAItem.length; i > 1; i--){
			query += "<Or>";	
		}
		for(var i = 0; i < QUAItem.length; i++){
			query += "<Eq><FieldRef Name='ID' />";                    
			query += "<Value Type='Counter'>"+ QUAItem[i][0] +"</Value></Eq>";
			if(i == 1 && i > 0){
			query += "</Or>";
			}
			if(i > 1){
			query += "</Or>";
			}				
		}
	}
	//One Parameter
	if((selFlavour != undefined) && (selBrand == undefined) && (selPlant == undefined) && (selPack == undefined) && (selRetailUnit == undefined)){
		query += "<Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq></And>";
	}
	if((selFlavour == undefined) && (selBrand != undefined) && (selPlant == undefined) && (selPack == undefined) && (selRetailUnit == undefined)){
		query += "<Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq></And>";
	}
	if((selFlavour == undefined) && (selBrand == undefined) && (selPlant != undefined) && (selPack == undefined) && (selRetailUnit == undefined)){
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And>";
	}
	if((selFlavour == undefined) && (selBrand == undefined) && (selPlant == undefined) && (selPack != undefined) && (selRetailUnit == undefined)){
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And>";
	}
	if((selFlavour == undefined) && (selBrand == undefined) && (selPlant == undefined) && (selPack == undefined) && (selRetailUnit != undefined)){
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And>";
	}
	
	//Two Parameter
	if((selFlavour != undefined) && (selBrand != undefined) && (selPlant == undefined) && (selPack == undefined) && (selRetailUnit == undefined)){
		query += "<And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq></And></And>";
	}

	if((selFlavour != undefined) && (selBrand == undefined) && (selPlant != undefined) && (selPack == undefined) && (selRetailUnit == undefined)){
		query += "<And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And></And>";
	}

	if((selFlavour != undefined) && (selBrand == undefined) && (selPlant == undefined) && (selPack != undefined) && (selRetailUnit == undefined)){
		query += "<And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And></And>";
	}
	
	if((selFlavour != undefined) && (selBrand == undefined) && (selPlant == undefined) && (selPack == undefined) && (selRetailUnit != undefined)){
		query += "<And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";
	}	

	if((selFlavour == undefined) && (selBrand != undefined) && (selPlant != undefined) && (selPack == undefined) && (selRetailUnit == undefined)){
		query += "<And><Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And></And>";
	}

	if((selFlavour == undefined) && (selBrand != undefined) && (selPlant == undefined) && (selPack != undefined) && (selRetailUnit == undefined)){
		query += "<And><Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And></And>";
	}

	if((selFlavour == undefined) && (selBrand != undefined) && (selPlant == undefined) && (selPack == undefined) && (selRetailUnit != undefined)){
		query += "<And><Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";
	}
	
	if((selFlavour == undefined) && (selBrand == undefined) && (selPlant != undefined) && (selPack != undefined) && (selRetailUnit == undefined)){
		query += "<And><Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And></And>";
	}	

	if((selFlavour == undefined) && (selBrand == undefined) && (selPlant != undefined) && (selPack == undefined) && (selRetailUnit != undefined)){
		query += "<And><Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";
	}	

	if((selFlavour == undefined) && (selBrand == undefined) && (selPlant == undefined) && (selPack != undefined) && (selRetailUnit != undefined)){
		query += "<And><Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";
	}	
	
	//Three Parameter
	if((selFlavour != undefined) && (selBrand != undefined) && (selPlant != undefined) && (selPack == undefined) && (selRetailUnit == undefined)){
		query += "<And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And></And>";
	}	
	
	if((selFlavour != undefined) && (selBrand != undefined) && (selPlant == undefined) && (selPack != undefined) && (selRetailUnit == undefined)){
		query += "<And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And></And>";
	}	
	
	if((selFlavour != undefined) && (selBrand != undefined) && (selPlant == undefined) && (selPack == undefined) && (selRetailUnit != undefined)){
		query += "<And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";
	}	

	if((selFlavour != undefined) && (selBrand == undefined) && (selPlant != undefined) && (selPack != undefined) && (selRetailUnit == undefined)){
		query += "<And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And></And>";
	}	
	
	if((selFlavour != undefined) && (selBrand == undefined) && (selPlant != undefined) && (selPack == undefined) && (selRetailUnit != undefined)){
		query += "<And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";
	}		
	
	if((selFlavour != undefined) && (selBrand == undefined) && (selPlant == undefined) && (selPack != undefined) && (selRetailUnit != undefined)){
		query += "<And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='selPack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";
	}		
	
	if((selFlavour == undefined) && (selBrand != undefined) && (selPlant != undefined) && (selPack != undefined) && (selRetailUnit == undefined)){
		query += "<And><And><Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='selPack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And></And>";
	}			

	if((selFlavour == undefined) && (selBrand != undefined) && (selPlant != undefined) && (selPack == undefined) && (selRetailUnit != undefined)){
		query += "<And><And><Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";
	}			

	if((selFlavour == undefined) && (selBrand != undefined) && (selPlant == undefined) && (selPack != undefined) && (selRetailUnit != undefined)){
		query += "<And><And><Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";
	}			

	if((selFlavour == undefined) && (selBrand == undefined) && (selPlant != undefined) && (selPack != undefined) && (selRetailUnit != undefined)){
		query += "<And><And><Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";
	}			

	//Four Parameter
	if((selFlavour != undefined) && (selBrand != undefined) && (selPlant != undefined) && (selPack != undefined) && (selRetailUnit == undefined)){
		query += "<And><And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And></And>";		
	}	
	
	if((selFlavour != undefined) && (selBrand != undefined) && (selPlant != undefined) && (selPack == undefined) && (selRetailUnit != undefined)){
		query += "<And><And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";		
	}		


	if((selFlavour != undefined) && (selBrand != undefined) && (selPlant == undefined) && (selPack != undefined) && (selRetailUnit != undefined)){
		query += "<And><And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";		
	}		


	if((selFlavour != undefined) && (selBrand == undefined) && (selPlant != undefined) && (selPack != undefined) && (selRetailUnit != undefined)){
		query += "<And><And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";		
	}		
	
	if((selFlavour == undefined) && (selBrand != undefined) && (selPlant != undefined) && (selPack != undefined) && (selRetailUnit != undefined)){
		query += "<And><And><And><Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";		
	}			
	

	//Five Parameter
	if((selFlavour != undefined) && (selBrand != undefined) && (selPlant != undefined) && (selPack != undefined) && (selRetailUnit != undefined)){
		query += "<And><And><And><And><Eq><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na' /><Value Type='Text'>"+ selFlavour +"</Value></Eq>";
		query += "<Eq><FieldRef Name='BrandID_x003a_Brand_x0020_Name' /><Value Type='Text'>"+ selBrand +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='LocationID_x003a_Location_x0020_' /><Value Type='Text'>"+ selPlant +"</Value></Eq></And>";
		query += "<Eq><FieldRef Name='Pack' /><Value Type='Text'>"+ selPack +"</Value></Eq></And>";		
		query += "<Eq><FieldRef Name='RetailUnitID_x003a_Title' /><Value Type='Text'>"+ selRetailUnit +"</Value></Eq></And></And>";				
	}	
	
	if(selMonth == "YTD"){
		query += "<OrderBy><FieldRef Name='ID' Ascending='True'/></OrderBy></Where></Query></View>";
	}
	else{
		query += "<OrderBy><FieldRef Name='ID' Ascending='True'/></OrderBy></Where></Query><RowLimit>"+ pageSize +"</RowLimit></View>";
	}
	
	camlQuery.set_viewXml(query);
	
	
	spReportItems = list.getItems(camlQuery);
	
	context.load(spReportItems);
	
	context.executeQueryAsync(
        function () {
            onReportSuccess();
        }, onReportFail);	
}

function onReportSuccess(){
    var listEnumerator = spReportItems.getEnumerator();
    var items = [];
    var item;
    if(listEnumerator.$2H_0 > 0){
	    while (listEnumerator.moveNext()) {
	    	$('.pager').show();
	    	item = listEnumerator.get_current();
	    	if(selMonth == "YTD"){
	    		ytdCollection.push(item.get_item('ID')+"_"+item.get_item('Title')+"_"+item.get_item('QAActualWeightRetailUnit')+"_"+item.get_item('TargetWeightRetailUnit')+"_"+
	    		item.get_item('LocationID_x003a_Location_x0020_').get_lookupValue()+"_"+item.get_item('BrandID_x003a_Brand_x0020_Name').get_lookupValue()+"_"+
	    		item.get_item('FlavourID_x003a_Flavour_x0020_Na').get_lookupValue()+"_"+item.get_item('CategoryID_x003a_Category_x0020_').get_lookupValue()+"_"+
	    		item.get_item('SalesUnitID_x003a_Title').get_lookupValue()+"_"+item.get_item('RetailUnitID_x003a_Title').get_lookupValue()+"_"+
	    		item.get_item('Pack')+"_"+item.get_item('SKUStaticName')+"_"+item.get_item('TargetWeightofSinglePiece')+"_"+item.get_item('TargetNoOfPiecesPerSaleUnit')+"_"+
	    		item.get_item('TargetWeightRetailUnit')+"_"+item.get_item('TargetNoOfSalesUnitPerRetailUnit')+"_"+item.get_item('DeclaredWeightPerRetailUnit'));    		
	    	}
	    	else{
		    	var skuID = item.get_id();
		        var QAActualWeightRetailUnit = item.get_item('QAActualWeightRetailUnit');
		        var TargetWeightRetailUnit = item.get_item('TargetWeightRetailUnit');        
		
		        calculateDelta(QAActualWeightRetailUnit,TargetWeightRetailUnit);
		        
		    	for(var i = 0; i < QUAItem.length; i++){
		    		if(QUAItem[i][0] == skuID){
		    			weightSinglePiece = QUAItem[i][1]; 
		    			noOfPieces = QUAItem[i][2];
		    			suPerRu = QUAItem[i][3];
		    			weightRU = QUAItem[i][4];
		    			break;
		    		}
		    	}
		    	
		        items.push("<td style='text-align: center;'>" +
				item.get_item('Title') +         
		        "</td><td style='text-align: center;'>" + item.get_item('LocationID_x003a_Location_x0020_').get_lookupValue() +       
		        "</td><td style='text-align: center;'>" + item.get_item('BrandID_x003a_Brand_x0020_Name').get_lookupValue() + 
		        "</td><td style='text-align: center;'>" + item.get_item('FlavourID_x003a_Flavour_x0020_Na').get_lookupValue() +
		        "</td><td style='text-align: center;'>" + item.get_item('CategoryID_x003a_Category_x0020_').get_lookupValue() +       
		        "</td><td style='text-align: center;'>" + item.get_item('SalesUnitID_x003a_Title').get_lookupValue() +       
		        "</td><td style='text-align: center;'>" + item.get_item('RetailUnitID_x003a_Title').get_lookupValue() + 
		        "</td><td style='text-align: center;'>" + item.get_item('Pack') +
		        "</td><td style='text-align: center;'>" + item.get_item('SKUStaticName') +       
				"</td><td style='background-color: #8DB4E2;text-align: center;'>" + item.get_item('TargetWeightofSinglePiece') +
		        "</td><td style='background-color: #8DB4E2;text-align: center;'>" + item.get_item('TargetNoOfPiecesPerSaleUnit') +       
		        "</td><td style='background-color: #8DB4E2;text-align: center;'>" + item.get_item('TargetNoOfSalesUnitPerRetailUnit') + 
		        "</td><td style='background-color: #8DB4E2;text-align: center;'>" + item.get_item('TargetWeightRetailUnit') +
		        "</td><td style='text-align: center;'>" + item.get_item('DeclaredWeightPerRetailUnit') +
				"</td><td style='background-color: Yellow;text-align: center;'>" + weightSinglePiece +
		        "</td><td style='background-color: Yellow;text-align: center;'>" + noOfPieces +       
		        "</td><td style='background-color: Yellow;text-align: center;'>" + suPerRu + 
		        "</td><td style='background-color: Yellow;text-align: center;'>" + weightRU +        
		        "</td><td style='text-align: center;'>" + Actualdelta +       	        
		        "</td>");
	    	}
	    }	
	    if(selMonth != "YTD"){
		    var content = "<div id='divGrid' style='overflow-x: scroll!Important;'><table class='Gridtable Gridtable-hover Gridtable-bordered'  id='pagingData'>" +
		    "<thead><tr><th colspan='9' style='text-align: center;'>PRODUCT DETAIL</th><th colspan='4' style='text-align: center;'>PRODUCT DETAIL</th>" +
		    "<td colspan='1' rowspan='2' style='text-align: center;'><strong>DECLARED WT/ RU</strong></td><th colspan='4' style='text-align: center;'>ACTUAL</th>" +
		    "<td colspan='1' rowspan='2' style='text-align: center;'><strong>DELTA</strong></td></tr><tr>"+
		    "<th style='text-align: center;'>SKU NO</th>" +	
		    "<th style='text-align: center;'>LOCATION</th>" +    
		    "<th style='text-align: center;'>BRAND NAME</th>" +
		    "<th style='text-align: center;'>FLAVOUR NAME</th>" +
		    "<th style='text-align: center;'>PRODUCT CATEGORY</th>" +
		    "<th style='text-align: center;'>SALES UNIT</th>" +
			"<th style='text-align: center;'>RETAIL UNIT</th>" +    
		    "<th style='text-align: center;'>PACK NAME</th>" +
		    "<th style='text-align: center;'>SKU NAME</th>" +
			"<th style='text-align: center;'>WEIGHT/SINGLE PIECE(G)</th>" +    
		    "<th style='text-align: center;'>NO OF PIECES/SU(PCS)</th>" +   
		    "<th style='text-align: center;'>NO OF SU/RU</th>" +
		    "<th style='text-align: center;'>WEIGHT/RU(G)</th>" +
			"<th style='text-align: center;'>WEIGHT/SINGLE PIECE(G)</th>" +    
		    "<th style='text-align: center;'>NO OF PIECES/SU(PCS)</th>" +   
		    "<th style='text-align: center;'>NO OF SU/RU</th>" +
		    "<th style='text-align: center;'>WEIGHT/RU(G)</th>" +
		    
		    "</tr></thead><tbody><tr>" + items.join("</tr><tr>") + "</tr></tbody></table></div>";
		
		    $('#content').html(content);
		
		    DivWidth();
		    managePagerControl();
	    }
	    if(selMonth == "YTD"){
	    	lstYTDRecord();
	    }
	}
	else{
		$('#content').html("<h1 style='color:red; text-align : center;'>No Record Found</h1>");
	}	    
}

function onReportFail(sender,args){
    alert('Failed to get items. Error:' + args.get_message());
}


function managePagerControl() {
    if (spReportItems.get_listItemCollectionPosition()) {
        nextPagingInfo = spReportItems.get_listItemCollectionPosition().get_pagingInfo();
    } else {
        nextPagingInfo = null;
    }

    //The following code line shall add page information between the next and back buttons 
    $("#pageInfo").html((((pageIndex - 1) * pageSize) + 1) + " - " + ((pageIndex * pageSize) - (pageSize - spReportItems.get_count())));

    previousPagingInfo = "PagedPrev=TRUE&Paged=TRUE&p_ID=" + spReportItems.itemAt(0).get_item('ID') + "&p_" + sortColumn + "=" + encodeURIComponent(spReportItems.itemAt(0).get_item(sortColumn));

    if (pageIndex <= 1) {
        $("#btnBack").attr('disabled', 'disabled');
    }
    else {
        $("#btnBack").removeAttr('disabled');
    }

    if (nextPagingInfo) {
        $("#btnNext").removeAttr('disabled');
    }
    else {
        $("#btnNext").attr('disabled', 'disabled');
    }
}
function splitYTD(){
	for(var i = 0; i < ytdCollection.length; i++){
		ytdItems.push(ytdCollection[i].split("_"));
	}
}
function lstYTDRecord(){
	var items = [];
	splitYTD();
	for(var i = 0; i < ytdItems.length; i++){
		for(var j = 0; j < QUAItem.length; j++){
			if(QUAItem[j][0] == ytdItems[i][0]){
		        calculateDelta(ytdItems[i][2],ytdItems[i][3]);
		        items.push("<td style='text-align: center;'>" +
				ytdItems[i][1] +         
		        "</td><td style='text-align: center;'>" + ytdItems[i][4] +       
		        "</td><td style='text-align: center;'>" + ytdItems[i][5] + 
		        "</td><td style='text-align: center;'>" + ytdItems[i][6] +
		        "</td><td style='text-align: center;'>" + ytdItems[i][7] +       
		        "</td><td style='text-align: center;'>" + ytdItems[i][8] +       
		        "</td><td style='text-align: center;'>" + ytdItems[i][9] + 
		        "</td><td style='text-align: center;'>" + ytdItems[i][10] +
		        "</td><td style='text-align: center;'>" + ytdItems[i][11] +       
				"</td><td style='background-color: #8DB4E2;text-align: center;'>" + ytdItems[i][12] +
		        "</td><td style='background-color: #8DB4E2;text-align: center;'>" + ytdItems[i][13] +       
		        "</td><td style='background-color: #8DB4E2;text-align: center;'>" + ytdItems[i][14] + 
		        "</td><td style='background-color: #8DB4E2;text-align: center;'>" + ytdItems[i][15] +
		        "</td><td style='text-align: center;'>" + ytdItems[i][16] +
				"</td><td style='background-color: Yellow;text-align: center;'>" + QUAItem[j][1] +
		        "</td><td style='background-color: Yellow;text-align: center;'>" + QUAItem[j][2] +       
		        "</td><td style='background-color: Yellow;text-align: center;'>" + QUAItem[j][3] + 
		        "</td><td style='background-color: Yellow;text-align: center;'>" + QUAItem[j][4] +        
		        "</td><td style='text-align: center;'>" + Actualdelta +       	        
		        "</td>");			
			}
		}
	}
    var content = "<div id='divGrid' style='overflow-x: scroll!Important;'><table class='Gridtable Gridtable-hover Gridtable-bordered'  id='pagingData'>" +
    "<thead><tr><th colspan='9' style='text-align: center;'>PRODUCT DETAIL</th><th colspan='4' style='text-align: center;'>PRODUCT DETAIL</th>" +
    "<td colspan='1' rowspan='2' style='text-align: center;'><strong>DECLARED WT/ RU</strong></td><th colspan='4' style='text-align: center;'>ACTUAL</th>" +
    "<td colspan='1' rowspan='2' style='text-align: center;'><strong>DELTA</strong></td></tr><tr>"+
    "<th style='text-align: center;'>SKU NO</th>" +	
    "<th style='text-align: center;'>LOCATION</th>" +    
    "<th style='text-align: center;'>BRAND NAME</th>" +
    "<th style='text-align: center;'>FLAVOUR NAME</th>" +
    "<th style='text-align: center;'>PRODUCT CATEGORY</th>" +
    "<th style='text-align: center;'>SALES UNIT</th>" +
	"<th style='text-align: center;'>RETAIL UNIT</th>" +    
    "<th style='text-align: center;'>PACK NAME</th>" +
    "<th style='text-align: center;'>SKU NAME</th>" +
	"<th style='text-align: center;'>WEIGHT/SINGLE PIECE(G)</th>" +    
    "<th style='text-align: center;'>NO OF PIECES/SU(PCS)</th>" +   
    "<th style='text-align: center;'>NO OF SU/RU</th>" +
    "<th style='text-align: center;'>WEIGHT/RU(G)</th>" +
	"<th style='text-align: center;'>WEIGHT/SINGLE PIECE(G)</th>" +    
    "<th style='text-align: center;'>NO OF PIECES/SU(PCS)</th>" +   
    "<th style='text-align: center;'>NO OF SU/RU</th>" +
    "<th style='text-align: center;'>WEIGHT/RU(G)</th>" +
    
    "</tr></thead><tbody><tr>" + items.join("</tr><tr>") + "</tr></tbody></table></div>";

    $('#content').html(content);

    DivWidth();
    $('#pagingData').paging({limit:200});
	$('.pageHide').hide();
	$('#btnBack').hide();
	$('#btnNext').hide();
	
}

// Export to Excel
function fnExcelReport()
{
	debugger;
    var tab_text="<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j=0;
    tab = document.getElementById('pagingData'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xlsx");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}


