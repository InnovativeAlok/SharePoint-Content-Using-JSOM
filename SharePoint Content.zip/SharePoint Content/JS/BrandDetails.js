var spItems,SKUItems,countSKUID,month,brandID,flavourID,delta,
    pvmiSKUList = 'lstPVMISKUList';
    var deltaArray = [];
    var lstSKUArr = [];
	var arrDelta = [];
	var dataPointsDelta = [];
	var lstSKU = [];
	var monthArr = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

// This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
$(document).ready(function () {
    debugger;
        brandID = GetParameterValues('BRANDID');  
        flavourID = GetParameterValues('FLAVOURID');
        delta = GetParameterValues('DELTA');
        if(delta == "NO%20PRODUCTION"){
        	delta = "NO PRODUCTION";
        }  
  
        function GetParameterValues(param) {  
            var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');  
            for (var i = 0; i < url.length; i++) {  
                var urlparam = url[i].split('=');  
                if (urlparam[0] == param) {  
                    return urlparam[1];  
                }  
            }  
        }       	
    // Make sure the SharePoint script file 'sp.js' is loaded before your code runs.
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', sharePointReady);
    // Create an instance of the current clientContext.
    function sharePointReady() {
        getBrandDetails(brandID,flavourID);
    }
});
function DivWidth()
{
	debugger;
 	var scWidth = screen.width;
        var newscWidth = scWidth * (4.4 / 100);
        scWidth = scWidth - newscWidth;
        var divGrid = document.getElementById('divGrid');
        divGrid.style.width = scWidth + 'px';
};

function getBrandDetails(brandId,flavourId) {
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle(pvmiSKUList);
    var camlQuery = new SP.CamlQuery();

    camlQuery.set_viewXml("<View><Query><Where><And><Eq><FieldRef Name='Status' /><Value Type='Text'>Approved</Value></Eq>"+
    						"<And><Eq><FieldRef Name='BrandID' /><Value Type='Text'>"+ brandId +"</Value></Eq>"+
    						"<Eq><FieldRef Name='FlavourID' /><Value Type='Text'>"+ flavourId +"</Value></Eq></And></And></Where></Query>"+
    						"<ViewFields><FieldRef Name='ID'/><FieldRef Name='BrandID_x003a_Brand_x0020_Name'/><FieldRef Name='Pack'/>"+
    						"<FieldRef Name='CategoryID_x003a_Category_x0020_'/><FieldRef Name='TargetWeightRetailUnit'/>"+
    						"<FieldRef Name='QAActualWeightRetailUnit'/><FieldRef Name='SalesUnitID_x003a_Title'/>"+
    						"<FieldRef Name='LocationID_x003a_Location_x0020_'/><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na'/>"+
    						"<FieldRef Name='RetailUnitID_x003a_Title'/></ViewFields></View>");


    spItems = list.getItems(camlQuery);

    context.load(spItems);

    context.executeQueryAsync(
                function () {
                    onSuccess();
                }, onFail);
}

// Create a CAML view that retrieves items with assigne RowLimit value to the query  

// This function is executed if the above OM call is successful 
// This function render the returns items to html table 
function onSuccess() {

    var listEnumerator = spItems.getEnumerator();
    var items = [];
    var lstID = [];
    var lstSKUitems = [];    
    var item;
	
	var sn = 1;
    while (listEnumerator.moveNext()) {
        item = listEnumerator.get_current();
        calculateDelta(item.get_item('QAActualWeightRetailUnit'),item.get_item('TargetWeightRetailUnit'));                
		lstID.push(item.get_item("ID"));			
        $('#brandName').text(item.get_item('BrandID_x003a_Brand_x0020_Name').get_lookupValue()); 
        $('#flavourName').text(item.get_item('FlavourID_x003a_Flavour_x0020_Na').get_lookupValue());
        $('#productCat').text(item.get_item('CategoryID_x003a_Category_x0020_').get_lookupValue());
        
        lstSKUitems.push("<td>" + sn +
        "</td><td>" + item.get_item('Pack')+ 
        "</td><td>" + item.get_item('SalesUnitID_x003a_Title').get_lookupValue() +
        "</td><td>" + item.get_item('RetailUnitID_x003a_Title').get_lookupValue() +
        "</td><td>" + Actualdelta +   
        "</td><td>" + item.get_item('LocationID_x003a_Location_x0020_').get_lookupValue());        
        sn++;
    }
    var content = "<div id='divGrid' style='overflow-x: scroll!Important;'><table class='Gridtable Gridtable-hover Gridtable-bordered'  id='pagingData'>" +
    "<thead><tr>"+
    "<th>S. NO.</th>" +
    "<th>PACK</th>" +
    "<th>SALES UNIT</th>" +
    "<th>RETAIL UNIT</th>" +
    "<th>DELTA(%)</th>" +
    "<th>LOCATION</th>" +
    "</tr></thead><tbody><tr>" + lstSKUitems.join("</tr><tr>") + "</tr></tbody></table></div>";

    $('#content').html(content);
    
    getSKUDetails(lstID);
    countSKUID = lstID.length;       
}

// This function is executed if the above call fails
function onFail(sender, args) {
    alert('Failed to get items. Error:' + args.get_message());
}



function getSKUDetails(lstSKUID){
    var context = SP.ClientContext.get_current();
    var list = context.get_web().get_lists().getByTitle('lstPVMSKUQA');

    var camlQuery = new SP.CamlQuery();
	var query = "";
	var rowQuery = "";
	query += "<View><Query><Where><And>";
	for(var i = lstSKUID.length; i > 1; i--){
		query += "<Or>";	
	}
	
	for(var i = 0; i < lstSKUID.length; i++){
		query += "<Eq><FieldRef Name='SKUID' />";                    
		query += "<Value Type='Lookup'>"+ lstSKUID[i] +"</Value></Eq>";
		if(i == 1 && i > 0){
		query += "</Or>";
		}
		if(i > 1){
		query += "</Or>";
		}			
	}
	
	
	
	query += "<Eq><FieldRef Name='Title' /><Value Type='Text'>2017</Value></Eq></And></Where><GroupBy Collapse='TRUE'><FieldRef Name='Month' /></GroupBy></Query>";	

	query += "<ViewFields><FieldRef Name='Pack'/><FieldRef Name='SKUID_x003a_TargetWeightRetailUn'/><FieldRef Name='Month'/>"+
				"<FieldRef Name='QAActualWeightRetailUnit'/><FieldRef Name='SalesUnitID_x003a_Title'/>"+
				"<FieldRef Name='RetailUnitID_x003a_Title'/><FieldRef Name='LocationID_x003a_Location_x0020_'/>"+
				"<FieldRef Name='Month'/><FieldRef Name='FlavourID_x003a_Flavour_x0020_Na'/>"+
				"<Aggregations Value='On'><FieldRef Name='QAActualWeightRetailUnit' Type='Sum' />"+
				"<FieldRef Name='SKUID_x003a_TargetWeightRetailUn' Type='Sum' /></Aggregations></ViewFields></View>";
				
    camlQuery.set_viewXml(query);


    SKUItems = list.getItems(camlQuery);

    context.load(SKUItems);

    context.executeQueryAsync(
                function () {
                    onSKUDetailSuccess();
                }, onSKUDetailFail);

}

function onSKUDetailSuccess(){
    var listEnumerator = SKUItems.getEnumerator();
    var SKUitem;
    while (listEnumerator.moveNext()) {
        SKUitem = listEnumerator.get_current();
        calculateDelta(SKUitem.get_item('QAActualWeightRetailUnit'),SKUitem.get_item('SKUID_x003a_TargetWeightRetailUn').get_lookupValue());
        lstSKUArr.push(SKUitem.get_item('Month')+"_"+Actualdelta);
        deltaArray.push(delta);
    }
    lstSKUDetails(lstSKUArr);    
}

function onSKUDetailFail(sender,args){
    alert('Failed to get items. Error:' + args.get_message());
}

function calculateDelta(QAW,TW){
        var QAActualWeightRetailUnit = QAW;
        var TargetWeightRetailUnit = TW;
        var preDelta = ((QAActualWeightRetailUnit/TargetWeightRetailUnit)*100);

		if(preDelta > 0 && preDelta != "Infinity"){
			delta = parseFloat(preDelta - 100).toFixed(2);
			Actualdelta = (delta).toString();
		}
		else{
			Actualdelta = "NO PRODUCTION";
		}
}

var deltaValue = [];

function lstSKUDetails(lstSKUArr){
	var arrDelta = [];
	var countDelta1 = 0.00,countDelta2 = 0.00,countDelta3 = 0.00,countDelta4 = 0.00,
		countDelta5 = 0.00,countDelta6 = 0.00,countDelta7 = 0.00,countDelta8 = 0.00,
		countDelta9 = 0.00,countDelta10 = 0.00,countDelta11 = 0.00,countDelta12 = 0.00;
	for(var j = 0; j < lstSKUArr.length; j++){
		lstSKU = lstSKUArr[j].split("_");
		if(lstSKU[1] == "NO PRODUCTION"){
			lstSKU[1] = 0.00;
		}
		if(lstSKU[0] == 1){
			countDelta1 += parseFloat(lstSKU[1]);
		}
		if(lstSKU[0] == 2){
			countDelta2 += parseFloat(lstSKU[1]);
		}	

		if(lstSKU[0] == 3){
			countDelta3 += parseFloat(lstSKU[1]);
		}

		if(lstSKU[0] == 4){		
			countDelta4 += parseFloat(lstSKU[1]);			
		}
		if(lstSKU[0] == 5){
			countDelta5 += parseFloat(lstSKU[1]);
		}
		if(lstSKU[0] == 6){
			countDelta6 += parseFloat(lstSKU[1]);
		}	

		if(lstSKU[0] == 7){
			countDelta7 += parseFloat(lstSKU[1]);
		}

		if(lstSKU[0] == 8){		
			countDelta8 += parseFloat(lstSKU[1]);			
		}
		if(lstSKU[0] == 9){
			countDelta9 += parseFloat(lstSKU[1]);
		}
		if(lstSKU[0] == 10){
			countDelta10 += parseFloat(lstSKU[1]);
		}	

		if(lstSKU[0] == 11){
			countDelta11 += parseFloat(lstSKU[1]);
		}

		if(lstSKU[0] == 12){		
			countDelta12 += parseFloat(lstSKU[1]);			
		}
		month = parseFloat(lstSKU[0]); 				
	}
	arrDelta.push((countDelta1/month).toFixed(2),((countDelta2/month).toFixed(2)),((countDelta3/month).toFixed(2)),((countDelta4/month).toFixed(2)),
				 ((countDelta5/month).toFixed(2)),((countDelta6/month).toFixed(2)),((countDelta7/month).toFixed(2)),((countDelta8/month).toFixed(2)),
				 ((countDelta9/month).toFixed(2)),((countDelta10/month).toFixed(2)),((countDelta11/month).toFixed(2)),((countDelta12/month).toFixed(2)));

	for(var i = 0; i < month; i++){
		dataPointsDelta.push({ label: monthArr[i], y: Number(arrDelta[i]) });								
	}
	var chart = new CanvasJS.Chart("chartContainer", {
		title:{
			text: "Delta Chart Representation"              
		},
		axisX:{
 	 		title: "Month",
 		},
		axisY:{
		 	title: "Delta(%)",
		}, 		
		data: [              
		{
			type: "line",
			dataPoints: dataPointsDelta
		}
		]
	});
chart.render();
}



